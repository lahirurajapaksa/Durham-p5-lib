#What I've changed
The original **'Pong Mania'** game contained the very basic version of Pong
featuring a black and white setup with one ball and two paddles.
In order to make things a bit more interesting, I created a menu screen which is able to access
4 different game modes of Pong that I made.

* **Crazy Mode** - generates 2 paddles and a ball of a random size
* **SPAWN! mode** - creates a plethora of balls for the user to interact with, acting as more of a messy art piece than a game mode
* **Normal Multiplayer** - Just regular Pong, but significantly upgraded from the original sketch
* **Multiplayer Ball Frenzy** - allows balls to be spawned as the user clicks the mouse, facilitating the user with choosing their own difficulty level as they progress in the game

#How to use the classes featured in the sketch
 ##Ball Class 
 - The class used to describe a two dimensional ball. It is 
specifically a two dimensional vector as it possess both a magnitude and direction. The datatype stores the 
x-coordinates, y-coordinates, speed along the x axis, speed along the y axis and the radius of the ball that is to be produced.
<br><br>
This class can be manipulated to produce different looking ball objects or to spawn countless numbers of balls within in an array and display them on the screen. 
<br><br><br>

**Fields:**
* x - x position of ball
* y - y position of ball
* ballvx - speed of the ball along the x axis
* ballvy - speed of the ball along the y axis
* r - the radius of the ball
<br><br>

**Methods:**

* collideleft and collideright - allows the ball to check whether it has collided with any paddle object and rebound accordingly using an appropriate angle, which would depend on where it collides with the paddle
* update - allows the x co-ordinates and y co-ordinates to be updated based upon the speed of the ball
* reset - allows the ball to be re-spawned at a random speed and angle from the centre of the canvas if it moves out of bounds of the vertical edges of the canvas
<br><br><br>


 ##Paddle Class
 - The class used to describe a two dimensional rectangle. It is defined in terms of its y co-ordinates as its x co-ordinates are fixed. The paddle class also possesses 
a width and height which can allow its shape to be customised. 
<br><br><br>

**Fields:**
* y - the y position of the paddle
* w - the width of the paddle
* h - the height of the paddle
* stepchange - moves the paddle depending on how the control keys are pressed by the user by updating 'y'
<br><br>

**Methods:**

* update - is able to change the y co-ordinates of the paddle depending on the *stepchange* variable
* show - displays the paddle to the user




