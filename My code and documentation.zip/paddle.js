class Paddle {
    constructor(isLeft) {
        //y coordinates
        this.y = height / 2;
        //width of paddle
        this.w = 20;
        //height of paddle
        this.h = 100;
        //stepchange variable which is related to the user holding down the key when moving the paddle
        this.stepchange = 0;

        //assigns the x position of the paddle depending on whether it is the left or the right paddle
        if (isLeft) {
            this.x = this.w;
        } else {
            this.x = width - this.w;
        }


    }

    update() {
        this.y += this.stepchange;
        //ensures that the paddle stays in between the playing regions due to the constrain function
        this.y = constrain(this.y, this.h / 2, height - this.h / 2);
    }
    //defines how far the paddle should be moved depending on the step count which is incremented when move control keys are held down
    move(steps) {
        this.stepchange = steps;
    }

    show() {
        //displays the paddle
        rectMode(CENTER);
        fill(random(255), random(255), random(255));
        rect(this.x, this.y, this.w, this.h);


    }


}