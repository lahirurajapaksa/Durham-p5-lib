class Ball {
    constructor() {
        //x and y position
        this.x = width / 2;
        this.y = height / 2;
        //x and y speeds
        this.ballvx = 0;
        this.ballvy = 0;
        //the radius of the ball
        this.r = 12;

        this.reset();
    }

    collideleft(p) {
        //function allows the ball to properly bounce off the paddle
        //if statement ensures that the ball is within the x and y co-ordinates in relation to its radius so that
        //it can bounce off the relevant paddle
        if (this.y - this.r < p.y + p.h / 2 &&
            this.y + this.r > p.y - p.h / 2 &&
            this.x - this.r < p.x + p.w / 2) {

            //this means that the x coordinate of the ball is greater than that of the ball and as a result it should rebound
            if (this.x > p.x) {
                //defines the different angles at which the ball would bounce off the paddle depending on where it hits the paddle
                let diff = this.y - (p.y - p.h / 2);
                let rad = radians(45);
                let angle = map(diff, 0, p.h, -rad, rad);
                this.ballvx = 5 * cos(angle);
                this.ballvy = 5 * sin(angle);
                this.x = p.x + p.w / 2 + this.r;
            }

        }
    }
    collideright(p) {
        //same as checkPaddleLeft except the last part of the if statement has this.x+this.r>p.x-p.w/2 because of the
        //horizontal difference between the two left and right paddles, as checkPaddleLeft had this.x+this.r<p.x+p.w
        if (this.y - this.r < p.y + p.h / 2 &&
            this.y + this.r > p.y - p.h / 2 &&
            this.x + this.r > p.x - p.w / 2) {

            //this means that the x coordinate of the ball is greater than that of the ball and as a result it should rebound
            if (this.x < p.x) {
                //defines the different angles at which the ball would bounce off the paddle depending on where it hits the paddle

                let difference = this.y - (p.y - p.h / 2);
                let angle = map(difference, 0, p.h, radians(225), radians(135));
                this.ballvx = 5 * cos(angle);
                this.ballvy = 5 * sin(angle);
                this.x = p.x - p.w / 2 - this.r;
            }
        }
    }
    //updates the position of the ball by adding on the speed to x and y coordinates
    update() {
        this.x += this.ballvx;
        this.y += this.ballvy;
    }
    //when the ball has gone out of bounds this function is called to respawn the ball
    reset() {
        //spawns it at the middle of the sketch
        this.x = width / 2;
        this.y = height / 2;
        //allows the ball to pop up at a random speed and angle when it has been generated
        let angle = random(-PI / 4, PI / 4);
        this.ballvx = 5 * Math.cos(angle);
        this.ballvy = 5 * Math.sin(angle);

        if (random(1) < 0.5) {
            this.ballvx *= -1;
        }
    }

    edges() {
        //if the ball hits the top or bottom edges, it then bounces back as its ballvy is made negative, sending it in the opposite y direction
        if (this.y < 0 || this.y > height) {
            this.ballvy *= -1;
        }
        //checks whether the ball has gone past the right side
        //this means there would be a point for the left player, which is why Lscore is incremented
        if (this.x - this.r > width) {
            Lscore++;
            this.reset();
        }
        //checks whether the ball has gone past the left side
        //this means there would be a point for the right player, which is why Rscore is incremented

        if (this.x + this.r < 0) {
            Rscore++;
            this.reset();
        }
    }

    show() {
        //displays the ball on screen
        fill(random(255), 0, random(255));
        ellipse(this.x, this.y, this.r * 2);
    }
}
